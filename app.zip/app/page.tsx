
import Header from '../components/Header'
import Footer from '../components/Footer'

export default function Home() {
  return (
    <main>
      <Header />

      <section className="max-w-6xl mx-auto px-4 py-20">
        <div className="text-center">
          <h1 className="text-5xl font-bold leading-tight">
            Privacy-First Productivity Tools
          </h1>

          <p className="mt-6 text-xl text-slate-300 max-w-2xl mx-auto">
            Free browser-based tools that work directly on your device.
            No uploads. No accounts. No tracking.
          </p>

          <a
            href="/scan-to-pdf"
            className="button"
          >
            Open Scan to PDF
          </a>
        </div>
      </section>

      <section className="max-w-6xl mx-auto px-4 grid md:grid-cols-2 gap-6">
        <div className="card">
          <h2 className="text-2xl font-bold">Scan to PDF</h2>
          <p className="mt-3 text-slate-300">
            Use your phone camera to scan documents and export PDFs locally.
          </p>
          <a href="/scan-to-pdf" className="button">
            Launch Tool
          </a>
        </div>

        <div className="card">
          <h2 className="text-2xl font-bold">Coming Soon</h2>
          <ul className="mt-3 text-slate-300 space-y-2">
            <li>• PDF Editor</li>
            <li>• OCR Scanner</li>
            <li>• Voice Inventory App</li>
          </ul>
        </div>
      </section>

      <section className="max-w-6xl mx-auto px-4 py-12">
        <div className="card text-center">
          <p className="text-slate-300 mb-4">
            Advertisement Area (non-intrusive banner)
          </p>

          <div className="bg-slate-800 rounded-lg p-6">
            Future AdSense / Ezoic placement
          </div>
        </div>
      </section>

      <section className="max-w-6xl mx-auto px-4 py-8">
        <div className="card">
          <h2 className="text-2xl font-bold">Install On Your Phone</h2>

          <p className="mt-3 text-slate-300">
            Add this website to your home screen for an app-like experience.
          </p>

          <ol className="mt-4 space-y-2 text-slate-300">
            <li>1. Open browser menu</li>
            <li>2. Tap “Add to Home Screen”</li>
            <li>3. Launch like a native app</li>
          </ol>
        </div>
      </section>

      <Footer />
    </main>
  )
}
